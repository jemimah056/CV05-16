# EcoFy - Eco-friendly Habit Tracker

🌱 **EcoFy** is a comprehensive web application designed to help users track and maintain eco-friendly habits, reduce their carbon footprint, and live more sustainably.

## Features

### 🔐 Authentication
- **Animated Sign-in Page** with beautiful plant animation
- Google OAuth integration (demo)
- Email/password authentication
- Multi-language support (English, Spanish, French, Hindi)

### 👤 User Onboarding
- **Language Selection** with flag icons
- **Personal Details Collection** with slideshow-style forms
- Progressive profile completion with animated progress bar

### 🏠 Home Dashboard
- **Daily Eco Activities** with interactive cards
- **Activity Tracking** with completion status
- **Points System** for gamification
- **Badge System** with social sharing capabilities

### 📱 Navigation & UI
- **Responsive Sidebar** with smooth animations
- **Dark/Light Mode** toggle
- **Beautiful Color Scheme** using shades of brown and green
- **Modern UI/UX** with smooth transitions and hover effects

### 🛍️ Eco Products Store
- **Product Catalog** featuring eco-friendly items
- Wooden brushes, bamboo toothbrushes, reusable bottles, etc.
- **Shopping Cart** functionality (demo)

### 📊 Progress Tracking
- **Habit Streaks** with fire emoji indicators
- **Weekly Progress** charts
- **Leaderboard** for competitive motivation
- **Team Challenges** for group participation

### 🔔 Notifications
- **Daily Reminders** for incomplete activities
- **Achievement Notifications** for completed goals
- **Browser Push Notifications** support

### 💾 Data Management
- **Local Storage** for offline functionality
- **Backend API** for data persistence
- **User Profile** management
- **Activity History** tracking

## Technology Stack

- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **Backend**: Node.js, Express.js
- **Storage**: Local Storage + JSON-based backend
- **Styling**: Custom CSS with CSS Grid and Flexbox
- **Icons**: Font Awesome
- **Fonts**: Google Fonts (Poppins)

## Installation & Setup

1. **Clone or download** the project files
2. **Install dependencies**:
   ```bash
   npm install
   ```
3. **Start the server**:
   ```bash
   npm start
   ```
4. **Open your browser** and navigate to `http://localhost:3000`

## Usage

1. **Sign In** using Google or email authentication
2. **Select your preferred language**
3. **Complete your profile** through the slideshow forms
4. **Start tracking** eco-friendly activities on the home page
5. **Earn badges** by completing 100% of daily activities
6. **Share achievements** on social media
7. **Explore eco-products** in the store section
8. **Monitor progress** through streaks and leaderboards

## Project Structure

```
EcoFy/
├── index.html          # Main HTML file with all pages
├── styles.css          # Complete CSS styling
├── script.js           # Frontend JavaScript functionality
├── server.js           # Backend Express server
├── package.json        # Node.js dependencies
└── README.md          # Project documentation
```

## Features in Detail

### Eco Activities
- Use Reusable Water Bottle (10 points)
- Walk or Bike Instead of Driving (15 points)
- Turn Off Lights When Leaving (8 points)
- Use Cloth Bags for Shopping (12 points)
- Plant a Tree or Herb (25 points)
- Recycle Paper and Plastic (10 points)

### Eco Products
- Bamboo Toothbrush ($12.99)
- Wooden Comb ($15.99)
- Reusable Water Bottle ($24.99)
- Organic Cotton Tote Bag ($18.99)
- Beeswax Food Wraps ($22.99)
- Solar Power Bank ($45.99)

### Animations & Effects
- **Floating logo animation** on sign-in page
- **Leaf growing animation** with staggered timing
- **Smooth page transitions** with fade effects
- **Card hover effects** with elevation
- **Progress bar animations** during profile setup
- **Badge celebration modal** with bounce animation

## API Endpoints

- `POST /api/user/save` - Save user data
- `GET /api/user/:userId` - Get user data
- `POST /api/activities/complete` - Update activity completion
- `GET /api/activities/:userId` - Get user activities
- `GET /api/leaderboard` - Get global leaderboard
- `GET /api/progress/:userId` - Get weekly progress

## Color Scheme

The app uses a beautiful eco-friendly color palette:
- **Primary Green**: #2d5016
- **Secondary Green**: #4a7c59
- **Light Green**: #7fb069
- **Accent Green**: #a7c957
- **Primary Brown**: #6f4e37
- **Secondary Brown**: #8b4513
- **Light Brown**: #a0522d
- **Accent Brown**: #cd853f

## Browser Support

- Chrome (recommended)
- Firefox
- Safari
- Edge
- Mobile browsers (responsive design)

## Future Enhancements

- Real Google OAuth integration
- Database integration (MongoDB/PostgreSQL)
- Push notification service
- Social media sharing APIs
- Advanced analytics dashboard
- Team challenge system
- Reward redemption system
- Carbon footprint calculator

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

MIT License - feel free to use this project for learning and development purposes.

---

**Made with 🌱 for a greener future!**
