// Global Variables
let currentUser = null;
let currentLanguage = 'en';
let currentSlide = 1;
let userActivities = [];
let completedActivities = [];
let userStreak = 0;
let isDarkMode = false;
let userHabits = [];
let userCredits = 0;

// Eco-friendly activities data
const ecoActivities = [
    {
        id: 1,
        title: "Use Reusable Water Bottle",
        description: "Replace single-use plastic bottles with a reusable one",
        icon: "fas fa-tint",
        points: 10,
        category: "waste-reduction"
    },
    {
        id: 2,
        title: "Walk or Bike Instead of Driving",
        description: "Choose eco-friendly transportation for short distances",
        icon: "fas fa-bicycle",
        points: 15,
        category: "transportation"
    },
    {
        id: 3,
        title: "Turn Off Lights When Leaving",
        description: "Save energy by switching off unnecessary lights",
        icon: "fas fa-lightbulb",
        points: 8,
        category: "energy"
    },
    {
        id: 4,
        title: "Use Cloth Bags for Shopping",
        description: "Avoid plastic bags by bringing reusable shopping bags",
        icon: "fas fa-shopping-bag",
        points: 12,
        category: "waste-reduction"
    },
    {
        id: 5,
        title: "Plant a Tree or Herb",
        description: "Contribute to green spaces by planting something new",
        icon: "fas fa-seedling",
        points: 25,
        category: "nature"
    },
    {
        id: 6,
        title: "Recycle Paper and Plastic",
        description: "Properly sort and recycle waste materials",
        icon: "fas fa-recycle",
        points: 10,
        category: "waste-reduction"
    }
];

// Eco-friendly products data (expanded)
const ecoProducts = [
    { name: 'Reusable Metal Straws', price: 6.99, image: '🥤', description: 'Ditch single-use plastic straws for these durable, reusable metal ones.' },
    { name: 'Reusable Shopping Bags', price: 4.99, image: '🛍️', description: 'Strong, foldable bags for all your shopping needs.' },
    { name: 'Beeswax Food Wraps', price: 12.99, image: '🍯', description: 'Reusable wraps to keep food fresh without plastic.' },
    { name: 'Silicone Zip Bags', price: 9.99, image: '🧊', description: 'Reusable, leak-proof bags for snacks and storage.' },
    { name: 'Refillable Cleaning Sprays', price: 7.99, image: '🧴', description: 'Eco-friendly cleaning sprays you can refill again and again.' },
    { name: 'Coconut Fiber/Bamboo Scrub Brushes', price: 5.99, image: '🥥', description: 'Natural, compostable brushes for dishes and cleaning.' },
    { name: 'Laundry Strips/Pods (Plastic-Free)', price: 8.99, image: '🧺', description: 'Zero-waste laundry strips or pods for clean clothes.' },
    { name: 'Compost Bins (Small Kitchen)', price: 14.99, image: '🗑️', description: 'Compact bins for easy kitchen composting.' },
    { name: 'Solar-Powered Lights', price: 19.99, image: '💡', description: 'Harness the sun for beautiful, energy-saving lights.' },
    { name: 'Plantable Pencils', price: 3.99, image: '✏️', description: 'Write, then plant the stub to grow herbs or flowers.' },
    { name: 'Eco Notebooks (Recycled Paper)', price: 6.49, image: '📒', description: 'Jot down notes in 100% recycled paper notebooks.' },
    { name: 'Biodegradable Phone Cases', price: 15.99, image: '📱', description: 'Protect your phone and the planet with compostable cases.' },
    { name: 'Upcycled Fabric Products', price: 11.99, image: '🧵', description: 'Bags, pouches, and more made from upcycled fabrics.' },
    { name: 'Eco Lunchboxes (Steel/Bamboo)', price: 17.99, image: '🍱', description: 'Durable, stylish lunchboxes made from sustainable materials.' }
];

// --- Motivational Quotes ---
const motivationalQuotes = [
    "Small steps every day lead to big changes.",
    "Your habits shape the future of our planet!",
    "Be the change you wish to see in the world.",
    "Every eco action counts!",
    "Consistency is the key to a greener world.",
    "Together, we can make a difference!"
];
function getRandomQuote() {
    return motivationalQuotes[Math.floor(Math.random() * motivationalQuotes.length)];
}

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
    loadUserData();
    initializeNotifications();
    
    if (currentUser) {
        showPage('homePage');
        loadActivities();
    }
});

// Page Navigation Functions
function showPage(pageId) {
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active');
    });
    
    document.getElementById(pageId).classList.add('active');
    closeSidebar();
}

// Sign In Functions
function signInWithGoogle() {
    showLoadingAnimation();
    
    setTimeout(() => {
        currentUser = {
            id: 'google_' + Date.now(),
            name: 'John Doe',
            email: 'john.doe@gmail.com',
            provider: 'google'
        };
        
        hideLoadingAnimation();
        showPage('languagePage');
        saveUserData();
    }, 2000);
}

function showEmailSignIn() {
    const emailForm = document.getElementById('emailForm');
    emailForm.style.display = emailForm.style.display === 'none' ? 'block' : 'none';
}

function signInWithEmail() {
    const email = document.getElementById('emailInput').value;
    const password = document.getElementById('passwordInput').value;
    
    if (!email || !password) {
        showNotification('Please fill in all fields', 'error');
        return;
    }
    
    showLoadingAnimation();
    
    setTimeout(() => {
        currentUser = {
            id: 'email_' + Date.now(),
            name: email.split('@')[0],
            email: email,
            provider: 'email'
        };
        
        hideLoadingAnimation();
        showPage('languagePage');
        saveUserData();
    }, 1500);
}

function toggleSignUp() {
    showNotification('Sign up functionality coming soon!', 'info');
}

// Language Selection
function selectLanguage(lang) {
    currentLanguage = lang;
    showPage('personalDetailsPage');
    saveUserData();
}

// Personal Details Functions
function nextSlide() {
    const currentSlideElement = document.getElementById(`slide${currentSlide}`);
    const input = currentSlideElement.querySelector('input, select');
    
    if (!input.value.trim()) {
        showNotification('Please fill in this field before continuing', 'warning');
        return;
    }
    
    saveSlideData(currentSlide, input.value);
    
    currentSlideElement.classList.remove('active');
    
    currentSlide++;
    const nextSlideElement = document.getElementById(`slide${currentSlide}`);
    if (nextSlideElement) {
        nextSlideElement.classList.add('active');
        updateProgressBar();
    }
}

function saveSlideData(slideNumber, value) {
    if (!currentUser) return;
    
    switch(slideNumber) {
        case 1:
            currentUser.name = value;
            break;
        case 2:
            currentUser.age = parseInt(value);
            break;
        case 3:
            const city = document.getElementById('userCity').value;
            const state = document.getElementById('userState').value;
            currentUser.city = city;
            currentUser.state = state;
            break;
        case 4:
            currentUser.ecoGoal = value;
            break;
    }
    
    saveUserData();
}

function updateProgressBar() {
    const progress = document.getElementById('detailsProgress');
    const percentage = (currentSlide / 4) * 100;
    progress.style.width = percentage + '%';
}

function completeProfile() {
    const ecoGoal = document.getElementById('ecoGoal').value;
    if (!ecoGoal) {
        showNotification('Please select your eco goal', 'warning');
        return;
    }
    
    saveSlideData(4, ecoGoal);
    showNotification('Profile completed successfully!', 'success');
    
    setTimeout(() => {
        showPage('homePage');
        loadActivities();
        updateSidebarUserInfo();
    }, 1500);
}

// Home Page Functions
function loadActivities() {
    const activitiesGrid = document.getElementById('activitiesGrid');
    activitiesGrid.innerHTML = '';
    
    const dailyActivities = getRandomActivities(5);
    
    dailyActivities.forEach(activity => {
        const activityCard = createActivityCard(activity);
        activitiesGrid.appendChild(activityCard);
    });
}

function getRandomActivities(count) {
    const shuffled = [...ecoActivities].sort(() => 0.5 - Math.random());
    return shuffled.slice(0, count);
}

function createActivityCard(activity) {
    const card = document.createElement('div');
    card.className = 'activity-card';
    card.onclick = () => toggleActivity(activity.id, card);
    
    const isCompleted = completedActivities.includes(activity.id);
    if (isCompleted) {
        card.classList.add('completed');
    }
    
    card.innerHTML = `
        <div class="activity-icon">
            <i class="${activity.icon}"></i>
        </div>
        <div class="activity-title">${activity.title}</div>
        <div class="activity-description">${activity.description}</div>
        <div class="activity-points">+${activity.points} points</div>
    `;
    
    return card;
}

function toggleActivity(activityId, cardElement) {
    const isCompleted = completedActivities.includes(activityId);
    
    if (isCompleted) {
        completedActivities = completedActivities.filter(id => id !== activityId);
        cardElement.classList.remove('completed');
        showNotification('Activity marked as incomplete', 'info');
    } else {
        completedActivities.push(activityId);
        cardElement.classList.add('completed');
        showNotification('Great job! Activity completed!', 'success');
        
        checkBadgeEligibility();
        updateStreak();
    }
    
    saveUserData();
}

function checkBadgeEligibility() {
    const completionPercentage = (completedActivities.length / ecoActivities.length) * 100;
    
    if (completionPercentage >= 100) {
        showBadgeModal();
    }
}

function showBadgeModal() {
    const modal = document.createElement('div');
    modal.className = 'badge-modal';
    modal.innerHTML = `
        <div class="badge-content">
            <div class="badge-icon">🏆</div>
            <h2>Congratulations!</h2>
            <p>You've earned the Eco Warrior badge!</p>
            <div class="badge-buttons">
                <button onclick="shareBadge()">Share on Social Media</button>
                <button onclick="closeBadgeModal()">Continue</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    addBadgeModalStyles();
}

function addBadgeModalStyles() {
    const style = document.createElement('style');
    style.textContent = `
        .badge-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 2000;
        }
        .badge-content {
            background: white;
            padding: 40px;
            border-radius: 15px;
            text-align: center;
            max-width: 400px;
            animation: badgeAppear 0.5s ease-out;
        }
        .badge-icon {
            font-size: 4em;
            margin-bottom: 20px;
            animation: bounce 1s infinite;
        }
        .badge-buttons {
            margin-top: 20px;
            display: flex;
            gap: 10px;
            justify-content: center;
        }
        .badge-buttons button {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 500;
        }
        @keyframes badgeAppear {
            from { opacity: 0; transform: scale(0.5); }
            to { opacity: 1; transform: scale(1); }
        }
        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
            40% { transform: translateY(-10px); }
            60% { transform: translateY(-5px); }
        }
    `;
    document.head.appendChild(style);
}

function shareBadge() {
    if (navigator.share) {
        navigator.share({
            title: 'EcoFy Achievement',
            text: 'I just earned the Eco Warrior badge on EcoFy! 🏆🌱',
            url: window.location.href
        });
    } else {
        const shareText = 'I just earned the Eco Warrior badge on EcoFy! 🏆🌱';
        navigator.clipboard.writeText(shareText);
        showNotification('Badge text copied to clipboard!', 'success');
    }
    closeBadgeModal();
}

function closeBadgeModal() {
    const modal = document.querySelector('.badge-modal');
    if (modal) {
        modal.remove();
    }
}

// Sidebar Functions
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('active');
}

function closeSidebar() {
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.remove('active');
}

function updateSidebarUserInfo() {
    if (currentUser) {
        document.getElementById('sidebarUserName').textContent = currentUser.name || 'User';
    }
}

// Sidebar Navigation Functions
function showEditProfile() {
    closeSidebar();
    showNotification('Edit Profile feature coming soon!', 'info');
}

function showLanguageChange() {
    closeSidebar();
    const langModal = document.createElement('div');
    langModal.className = 'modal';
    langModal.innerHTML = `
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2>Change Language</h2>
            <div class="language-options">
                <button class="language-btn" onclick="selectLanguage('en'); closeModal();">
                    <span class="flag">🇺🇸</span> English
                </button>
                <button class="language-btn" onclick="selectLanguage('es'); closeModal();">
                    <span class="flag">🇪🇸</span> Español
                </button>
                <button class="language-btn" onclick="selectLanguage('fr'); closeModal();">
                    <span class="flag">🇫🇷</span> Français
                </button>
                <button class="language-btn" onclick="selectLanguage('hi'); closeModal();">
                    <span class="flag">🇮🇳</span> हिंदी
                </button>
            </div>
        </div>
    `;
    document.body.appendChild(langModal);
    addModalStyles();
}

// --- About Modal Expansion ---
function showAboutUs() {
    closeSidebar();
    const aboutModal = document.createElement('div');
    aboutModal.className = 'modal';
    aboutModal.innerHTML = `
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2>About EcoFy</h2>
            <p><b>EcoFy</b> is your personal eco-friendly habit tracker designed to help you reduce your carbon footprint and live more sustainably. We believe small daily actions can create a big impact for our planet.</p>
            <ul style="margin-bottom: 1em;">
                <li>🌱 Track eco-friendly habits and earn rewards</li>
                <li>🌍 Compete with friends and teams on the leaderboard</li>
                <li>📈 Visualize your weekly progress and streaks</li>
                <li>🤝 Join team challenges for collective impact</li>
            </ul>
            <p>Our mission is to make environmental consciousness accessible, fun, and rewarding for everyone. <br> <b>Start your green journey today!</b></p>
        </div>
    `;
    document.body.appendChild(aboutModal);
    addModalStyles();
}

function showProducts() {
    closeSidebar();
    const productsModal = document.createElement('div');
    productsModal.className = 'modal';
    
    let productsHTML = `
        <div class="modal-content products-modal">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2>Eco-Friendly Products</h2>
            <div class="products-grid">
    `;
    
    ecoProducts.forEach(product => {
        productsHTML += `
            <div class="product-card">
                <div class="product-image">${product.image}</div>
                <h3>${product.name}</h3>
                <p>${product.description}</p>
                <div class="product-price">$${product.price}</div>
                <button onclick="buyProduct(${ecoProducts.indexOf(product)})">Add to Cart</button>
            </div>
        `;
    });
    
    productsHTML += `
            </div>
        </div>
    `;
    
    productsModal.innerHTML = productsHTML;
    document.body.appendChild(productsModal);
    addModalStyles();
}

function addModalStyles() {
    if (document.querySelector('#modal-styles')) return;
    
    const style = document.createElement('style');
    style.id = 'modal-styles';
    style.textContent = `
        .modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 2000;
        }
        .modal-content {
            background: white;
            padding: 30px;
            border-radius: 15px;
            max-width: 90%;
            max-height: 90%;
            overflow-y: auto;
            position: relative;
        }
        .products-modal {
            max-width: 800px;
        }
        .close {
            position: absolute;
            top: 15px;
            right: 20px;
            font-size: 28px;
            cursor: pointer;
            color: #999;
        }
        .close:hover {
            color: #000;
        }
        .products-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .product-card {
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            transition: transform 0.3s ease;
        }
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .product-image {
            font-size: 3em;
            margin-bottom: 10px;
        }
        .product-price {
            font-size: 1.2em;
            font-weight: bold;
            color: var(--secondary-green);
            margin: 10px 0;
        }
        .product-card button {
            background: var(--secondary-green);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background 0.3s ease;
        }
        .product-card button:hover {
            background: var(--primary-green);
        }
    `;
    document.head.appendChild(style);
}

// --- Cart and Checkout Logic ---
let cart = [];
function buyProduct(productIndex) {
    const product = ecoProducts[productIndex];
    cart.push(product);
    showCartOptionsPage(product);
}

function showCartOptionsPage(product) {
    // Remove any existing modals
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => modal.remove());
    
    const cartModal = document.createElement('div');
    cartModal.className = 'modal';
    cartModal.innerHTML = `
        <div class="modal-content cart-options-modal">
            <span class="close" onclick="closeModal()">&times;</span>
            <div class="cart-success-message">
                <i class="fas fa-check-circle"></i>
                <h2>Added to Cart!</h2>
                <p>${product.name} has been added to your cart</p>
            </div>
            <div class="cart-options">
                <button class="buy-now-btn" onclick="proceedToCheckout()">
                    <i class="fas fa-bolt"></i>
                    Buy Now
                </button>
                <button class="view-cart-btn" onclick="showCartPage()">
                    <i class="fas fa-shopping-cart"></i>
                    View Cart (${cart.length})
                </button>
                <button class="continue-shopping-btn" onclick="closeModal()">
                    <i class="fas fa-arrow-left"></i>
                    Continue Shopping
                </button>
            </div>
        </div>
    `;
    document.body.appendChild(cartModal);
    addModalStyles();
    addCartOptionsStyles();
}

function showCartPage() {
    closeModal();
    const cartModal = document.createElement('div');
    cartModal.className = 'modal';
    
    let cartHTML = `
        <div class="modal-content cart-page-modal">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2><i class="fas fa-shopping-cart"></i> Your Cart</h2>
    `;
    
    if (cart.length === 0) {
        cartHTML += `
            <div class="empty-cart">
                <i class="fas fa-shopping-cart"></i>
                <p>Your cart is empty</p>
                <button class="continue-shopping-btn" onclick="closeModal()">Continue Shopping</button>
            </div>
        `;
    } else {
        let total = 0;
        cartHTML += '<div class="cart-items">';
        
        cart.forEach((item, index) => {
            const price = parseFloat(item.price.replace('$', ''));
            total += price;
            cartHTML += `
                <div class="cart-item">
                    <div class="cart-item-info">
                        <h4>${item.name}</h4>
                        <p class="cart-item-price">${item.price}</p>
                    </div>
                    <button class="remove-item-btn" onclick="removeFromCart(${index})">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            `;
        });
        
        cartHTML += `
            </div>
            <div class="cart-total">
                <h3>Total: $${total.toFixed(2)}</h3>
            </div>
            <div class="cart-actions">
                <button class="checkout-btn" onclick="proceedToCheckout()">
                    <i class="fas fa-credit-card"></i>
                    Proceed to Checkout
                </button>
                <button class="continue-shopping-btn" onclick="closeModal()">
                    Continue Shopping
                </button>
            </div>
        `;
    }
    
    cartHTML += '</div>';
    cartModal.innerHTML = cartHTML;
    document.body.appendChild(cartModal);
    addModalStyles();
    addCartPageStyles();
}

function removeFromCart(index) {
    cart.splice(index, 1);
    showCartPage(); // Refresh the cart page
}

function proceedToCheckout() {
    closeModal();
    showCheckoutForm();
}
function showCheckoutForm() {
    // Replace modal content with checkout form
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => modal.remove());
    const checkoutModal = document.createElement('div');
    checkoutModal.className = 'modal';
    checkoutModal.innerHTML = `
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2>Checkout</h2>
            <form id="checkoutForm">
                <label>Name:<br><input type="text" name="name" required></label><br>
                <label>Phone Number:<br><input type="tel" name="phone" required></label><br>
                <label>Address:<br><input type="text" name="address" required></label><br>
                <label>Location:<br><input type="text" name="location" required></label><br>
                <label>Payment Method:<br>
                    <select name="payment" required>
                        <option value="cod">Cash on Delivery</option>
                        <option value="online">Online Payment</option>
                    </select>
                </label><br>
                <button type="submit" class="challenge-btn">Place Order</button>
            </form>
        </div>
    `;
    document.body.appendChild(checkoutModal);
    addModalStyles();
    document.getElementById('checkoutForm').onsubmit = function(e) {
        e.preventDefault();
        closeModal();
        showOrderConfirmation();
    };
}
function showOrderConfirmation() {
    const confirmModal = document.createElement('div');
    confirmModal.className = 'modal';
    confirmModal.innerHTML = `
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2>Order Placed!</h2>
            <p>Thank you for your purchase. Your eco-friendly products are on the way! 🌱</p>
        </div>
    `;
    document.body.appendChild(confirmModal);
    addModalStyles();
}

function showSettings() {
    closeSidebar();
    const settingsModal = document.createElement('div');
    settingsModal.className = 'modal';
    settingsModal.innerHTML = `
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2>Settings</h2>
            <div class="settings-options">
                <div class="setting-item">
                    <label>Dark Mode</label>
                    <button onclick="toggleDarkMode()" class="toggle-btn">
                        ${isDarkMode ? 'Disable' : 'Enable'}
                    </button>
                </div>
                <div class="setting-item">
                    <button onclick="logout()" class="logout-btn">Log Out</button>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(settingsModal);
    addModalStyles();
}

function closeModal() {
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => modal.remove());
}

// Stats Functions
// --- Leaderboard Modal ---
function showLeaderboard() {
    const modal = document.getElementById('leaderboardModal');
    modal.style.display = 'flex';
    modal.innerHTML = `
        <div class="modal-content">
            <span class="close" onclick="closeLeaderboard()">&times;</span>
            <h2>Leaderboard</h2>
            <ol class="leaderboard-list">
                <li><span>🌟</span> Alice <b>1200 pts</b></li>
                <li><span>🥈</span> Bob <b>950 pts</b></li>
                <li><span>🥉</span> You <b>${getUserScore()} pts</b></li>
                <li>Charlie <b>800 pts</b></li>
                <li>Priya <b>700 pts</b></li>
            </ol>
            <p style="margin-top:1em;">Climb the leaderboard by completing more eco-friendly habits!</p>
        </div>
    `;
    addModalStyles();
}
function closeLeaderboard() {
    document.getElementById('leaderboardModal').style.display = 'none';
}
function getUserScore() {
    // Demo: 10 points per completed activity
    return (completedActivities.length * 10) + userStreak * 5;
}
// --- Weekly Progress Modal ---
function showWeeklyProgress() {
    const modal = document.getElementById('weeklyProgressModal');
    modal.style.display = 'flex';
    modal.innerHTML = `
        <div class="modal-content">
            <span class="close" onclick="closeWeeklyProgress()">&times;</span>
            <h2>Weekly Progress</h2>
            <div class="weekly-progress-bar">
                <div class="progress-day" style="height:60px;">Mon<br><div class="bar" style="height:40px;background:var(--light-green);"></div></div>
                <div class="progress-day" style="height:60px;">Tue<br><div class="bar" style="height:50px;background:var(--accent-green);"></div></div>
                <div class="progress-day" style="height:60px;">Wed<br><div class="bar" style="height:30px;background:var(--secondary-green);"></div></div>
                <div class="progress-day" style="height:60px;">Thu<br><div class="bar" style="height:60px;background:var(--primary-green);"></div></div>
                <div class="progress-day" style="height:60px;">Fri<br><div class="bar" style="height:20px;background:var(--pale-green);"></div></div>
                <div class="progress-day" style="height:60px;">Sat<br><div class="bar" style="height:55px;background:var(--light-green);"></div></div>
                <div class="progress-day" style="height:60px;">Sun<br><div class="bar" style="height:35px;background:var(--accent-green);"></div></div>
            </div>
            <p style="margin-top:1em;">Keep up your eco habits every day for a perfect streak!</p>
        </div>
    `;
    addModalStyles();
}
function closeWeeklyProgress() {
    document.getElementById('weeklyProgressModal').style.display = 'none';
}
// --- Team Challenges Modal ---
function showChallenges() {
    const modal = document.getElementById('teamChallengesModal');
    modal.style.display = 'flex';
    modal.innerHTML = `
        <div class="modal-content">
            <span class="close" onclick="closeTeamChallenges()">&times;</span>
            <h2>Team Challenges</h2>
            <p>Join forces with friends or colleagues to complete eco-friendly challenges together!</p>
            <ul>
                <li>🌳 <b>Plant 100 trees as a team</b> - Progress: 45%</li>
                <li>🚴 <b>Bike to work for a week</b> - Progress: 60%</li>
                <li>♻️ <b>Recycle 500 items</b> - Progress: 80%</li>
            </ul>
            <p style="margin-top:1em;">Invite others and make a bigger impact. <b>Teamwork makes the dream work!</b></p>
        </div>
    `;
    addModalStyles();
}
function closeTeamChallenges() {
    document.getElementById('teamChallengesModal').style.display = 'none';
}

function showHabitStreaks() {
    const streakModal = document.createElement('div');
    streakModal.className = 'modal';
    streakModal.innerHTML = `
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2>Habit Streaks</h2>
            <div class="streak-display">
                <div class="streak-number">${userStreak}</div>
                <div class="streak-label">Day Streak</div>
                <div class="streak-fire">🔥</div>
            </div>
            <p>Keep up the great work! Complete activities daily to maintain your streak.</p>
        </div>
    `;
    document.body.appendChild(streakModal);
    addModalStyles();
}

// Utility Functions
function showLoadingAnimation() {
    const loader = document.createElement('div');
    loader.id = 'loader';
    loader.innerHTML = `
        <div class="loading-spinner"></div>
        <p>Signing you in...</p>
    `;
    document.body.appendChild(loader);
    
    const style = document.createElement('style');
    style.textContent = `
        #loader {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.9);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            z-index: 3000;
        }
        .loading-spinner {
            width: 50px;
            height: 50px;
            border: 5px solid #f3f3f3;
            border-top: 5px solid var(--secondary-green);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    `;
    document.head.appendChild(style);
}

function hideLoadingAnimation() {
    const loader = document.getElementById('loader');
    if (loader) {
        loader.remove();
    }
}

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    if (!document.querySelector('#notification-styles')) {
        const style = document.createElement('style');
        style.id = 'notification-styles';
        style.textContent = `
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 15px 20px;
                border-radius: 8px;
                color: white;
                font-weight: 500;
                z-index: 4000;
                animation: slideInRight 0.3s ease-out;
            }
            .notification.success { background: var(--secondary-green); }
            .notification.error { background: #e74c3c; }
            .notification.warning { background: #f39c12; }
            .notification.info { background: var(--accent-brown); }
            @keyframes slideInRight {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
        `;
        document.head.appendChild(style);
    }
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

function updateStreak() {
    userStreak++;
    saveUserData();
}

// Settings Functions
function toggleDarkMode() {
    isDarkMode = !isDarkMode;
    document.body.classList.toggle('dark-mode', isDarkMode);
    saveUserData();
    closeModal();
    showNotification(`Dark mode ${isDarkMode ? 'enabled' : 'disabled'}`, 'success');
}

function logout() {
    if (confirm('Are you sure you want to log out?')) {
        currentUser = null;
        completedActivities = [];
        userStreak = 0;
        localStorage.removeItem('ecofy_user_data');
        closeModal();
        showPage('signInPage');
        showNotification('Logged out successfully', 'success');
    }
}

// Data Management Functions
function saveUserData() {
    const userData = {
        user: currentUser,
        language: currentLanguage,
        completedActivities: completedActivities,
        streak: userStreak,
        darkMode: isDarkMode,
        lastActive: new Date().toISOString()
    };
    
    localStorage.setItem('ecofy_user_data', JSON.stringify(userData));
}

function loadUserData() {
    const savedData = localStorage.getItem('ecofy_user_data');
    if (savedData) {
        const userData = JSON.parse(savedData);
        currentUser = userData.user;
        currentLanguage = userData.language || 'en';
        completedActivities = userData.completedActivities || [];
        userStreak = userData.streak || 0;
        isDarkMode = userData.darkMode || false;
        
        if (isDarkMode) {
            document.body.classList.add('dark-mode');
        }
        
        updateSidebarUserInfo();
    }
}

// Notification System
function initializeNotifications() {
    if ('Notification' in window && Notification.permission === 'default') {
        setTimeout(() => {
            Notification.requestPermission();
        }, 5000);
    }
    
    setDailyReminders();
}

function setDailyReminders() {
    setInterval(() => {
        const now = new Date();
        const hour = now.getHours();
        
        if (hour === 18 && completedActivities.length === 0) {
            sendNotification(
                'EcoFy Reminder',
                "Don't forget to complete your eco-friendly activities today! 🌱"
            );
        }
    }, 3600000);
}

function sendNotification(title, body) {
    if ('Notification' in window && Notification.permission === 'granted') {
        new Notification(title, {
            body: body,
            icon: '/favicon.ico'
        });
    }
}

// --- Daily Reminder for Incomplete Tasks ---
function setDailyTaskReminder() {
    // Check every hour if it's after 6pm and no tasks are done
    setInterval(() => {
        const now = new Date();
        const hour = now.getHours();
        if (hour === 18 && completedActivities.length === 0) {
            sendTaskReminder();
        }
    }, 60 * 60 * 1000); // every hour
}
function sendTaskReminder() {
    if ('Notification' in window && Notification.permission === 'granted') {
        new Notification('EcoFy Reminder', {
            body: "Don't forget to complete your eco-friendly habits today! 🌱",
            icon: '/favicon.ico'
        });
    } else {
        showNotification("Don't forget to complete your eco-friendly habits today! 🌱", 'warning');
    }
}
// --- Streak Top Right Update ---
function updateStreakTopRight() {
    const streakCount = document.getElementById('streakCount');
    if (streakCount) streakCount.textContent = userStreak;
}
// --- Populate Suggested Habits ---
function populateSuggestedHabits() {
    const list = document.getElementById('suggestedHabitsList');
    if (!list) return;
    list.innerHTML = '';
    const suggestions = [
        { title: 'Use a reusable water bottle', desc: 'Avoid single-use plastic bottles' },
        { title: 'Switch off lights when leaving', desc: 'Save energy and reduce carbon footprint' },
        { title: 'Take shorter showers', desc: 'Conserve water and energy' },
        { title: 'Use public transport or bike', desc: 'Reduce vehicle emissions' },
        { title: 'Recycle properly', desc: 'Sort and recycle your waste' }
    ];
    suggestions.forEach(habit => {
        const li = document.createElement('li');
        li.innerHTML = `<b>${habit.title}</b><br><span style='font-size:0.95em;color:#888;'>${habit.desc}</span>`;
        list.appendChild(li);
    });
}
// --- Populate User Habits (Demo) ---
function populateUserHabits() {
    const container = document.getElementById('userEcoHabits');
    if (!container) return;
    if (userHabits.length === 0) {
        container.innerHTML = `<div style='text-align:center;opacity:0.7;margin:2em 0;'><i class='fas fa-leaf' style='font-size:2em;'></i><br>No habits yet!<br><span style='font-size:0.95em;'>Add your first eco-friendly habit to get started.</span></div>`;
    } else {
        container.innerHTML = '<ul>' + userHabits.map(habit => {
            return `<li><b>${habit.title}</b> <span style='color:var(--secondary-green);'>(Added by you)</span></li>`;
        }).join('') + '</ul>';
    }
}
// --- Add Habit Modal (Demo) ---
function showAddHabitModal() {
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.innerHTML = `
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2>Add New Eco-Friendly Habit</h2>
            <input type="text" id="newHabitInput" placeholder="Describe your new habit..." style="width:100%;padding:12px;margin:18px 0;">
            <button onclick="addNewHabit()" style="width:100%;padding:12px;background:var(--secondary-green);color:white;border:none;border-radius:8px;font-size:1em;">Add Habit</button>
        </div>
    `;
    document.body.appendChild(modal);
    addModalStyles();
}
// --- Checklist and Eco Score Logic (with user habits) ---
function renderEcoChecklist() {
    const checklist = document.getElementById('ecoChecklist');
    if (!checklist) return;
    checklist.innerHTML = '';
    // Combine default and user habits
    const allHabits = [...ecoActivities, ...userHabits];
    allHabits.forEach(activity => {
        const li = document.createElement('li');
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.id = 'chk_' + activity.id;
        checkbox.checked = completedActivities.includes(activity.id);
        checkbox.addEventListener('change', () => toggleChecklistActivity(activity.id));
        // Add icon for each habit
        const icon = document.createElement('span');
        icon.className = 'habit-icon';
        icon.innerHTML = activity.icon ? `<i class='${activity.icon}'></i>` : '🌱';
        const label = document.createElement('label');
        label.htmlFor = checkbox.id;
        label.innerHTML = `<b>${activity.title}</b> <span style='font-size:0.95em;color:#888;'>${activity.description || ''}</span>`;
        li.appendChild(checkbox);
        li.appendChild(icon);
        li.appendChild(label);
        checklist.appendChild(li);
    });
    updateEcoScoreUI();
}
function toggleChecklistActivity(activityId) {
    const idx = completedActivities.indexOf(activityId);
    if (idx === -1) {
        completedActivities.push(activityId);
    } else {
        completedActivities.splice(idx, 1);
    }
    saveUserData();
    renderEcoChecklist();
    checkBadgeEligibility();
    populateUserHabits();
    updateStreakTopRight();
}
function updateEcoScoreUI() {
    const total = ecoActivities.length + userHabits.length; // Total habits including user ones
    const completed = completedActivities.length;
    const percent = total === 0 ? 0 : Math.round((completed / total) * 100);
    document.getElementById('ecoScoreText').textContent = `${completed} of ${total} habits completed`;
    document.getElementById('ecoScoreProgress').style.width = percent + '%';
    // Show badge download if all completed
    document.getElementById('downloadBadgeBtn').style.display = (completed === total && total > 0) ? 'inline-flex' : 'none';
}
// --- Badge Download Logic ---
function downloadGreenHeroBadge() {
    // Simple canvas badge
    const canvas = document.createElement('canvas');
    canvas.width = 400;
    canvas.height = 200;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#a7c957';
    ctx.fillRect(0, 0, 400, 200);
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 28px Poppins, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('Green Hero', 200, 70);
    ctx.font = '20px Poppins, sans-serif';
    ctx.fillText('Congratulations!', 200, 110);
    ctx.font = '16px Poppins, sans-serif';
    ctx.fillText('You completed all eco habits!', 200, 145);
    ctx.fillText('🏅', 200, 180);
    const link = document.createElement('a');
    link.download = 'green-hero-badge.png';
    link.href = canvas.toDataURL();
    link.click();
}
// --- Streak Rewards ---
function checkStreakRewards() {
    let badge = null, credits = 0;
    if (userStreak === 25) { badge = 'Silver'; credits = 25; }
    else if (userStreak === 50) { badge = 'Bronze'; credits = 50; }
    else if (userStreak === 75) { badge = 'Gold'; credits = 75; }
    else if (userStreak === 100) { badge = 'Diamond'; credits = 200; }
    if (badge) {
        userCredits += credits;
        showNotification(`Congratulations! You earned a ${badge} badge and ${credits} coins!`, 'success');
        showBadgeDownloadOption(badge);
        saveUserData();
    }
}
function showBadgeDownloadOption(badge) {
    const btn = document.createElement('button');
    btn.className = 'download-badge-btn';
    btn.innerHTML = `<i class='fas fa-award'></i> Download ${badge} Badge`;
    btn.onclick = () => downloadStreakBadge(badge);
    document.querySelector('.eco-score-section').appendChild(btn);
}
function downloadStreakBadge(badge) {
    const canvas = document.createElement('canvas');
    canvas.width = 400;
    canvas.height = 200;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#a7c957';
    ctx.fillRect(0, 0, 400, 200);
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 28px Poppins, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(`${badge} Badge`, 200, 70);
    ctx.font = '20px Poppins, sans-serif';
    ctx.fillText('Congratulations!', 200, 110);
    ctx.font = '16px Poppins, sans-serif';
    ctx.fillText('EcoFy Streak Milestone!', 200, 145);
    ctx.fillText('🏅', 200, 180);
    const link = document.createElement('a');
    link.download = `${badge.toLowerCase()}-badge.png`;
    link.href = canvas.toDataURL();
    link.click();
}
// --- Patch: Render checklist and eco score on load ---
window.addEventListener('DOMContentLoaded', () => {
    renderEcoChecklist();
    populateSuggestedHabits();
    populateUserHabits();
    updateStreakTopRight();
    setDailyTaskReminder(); // Start the daily reminder on load
});
// --- Patch: Update streak top right and user habits on activity toggle ---
const origToggleActivity2 = toggleActivity;
toggleActivity = function(activityId, cardElement) {
    origToggleActivity2(activityId, cardElement);
    renderEcoChecklist();
    populateUserHabits();
    updateStreakTopRight();
};
// --- Patch: Update streak top right on streak update ---
const origUpdateStreak2 = updateStreak;
updateStreak = function() {
    origUpdateStreak2();
    updateStreakTopRight();
    checkStreakRewards();
};
// --- Patch: Show motivational quote below eco score ---
function renderEcoScoreQuote() {
    let quote = getRandomQuote();
    let quoteDiv = document.getElementById('ecoScoreQuote');
    if (!quoteDiv) {
        quoteDiv = document.createElement('div');
        quoteDiv.id = 'ecoScoreQuote';
        quoteDiv.className = 'eco-score-quote';
        document.querySelector('.eco-score-section').appendChild(quoteDiv);
    }
    quoteDiv.textContent = quote;
}
// --- Patch: Render quote on checklist render ---
const origRenderEcoChecklist = renderEcoChecklist;
renderEcoChecklist = function() {
    origRenderEcoChecklist();
    renderEcoScoreQuote();
};

// --- Progress Page Logic ---
function renderProgressPage() {
    const container = document.getElementById('progressCharts');
    if (!container) return;
    container.innerHTML = '';
    // Weekly progress chart (simple bar chart using canvas)
    const canvas = document.createElement('canvas');
    canvas.width = 320;
    canvas.height = 120;
    container.appendChild(canvas);
    const ctx = canvas.getContext('2d');
    // Fake data: completed habits per day (Mon-Sun)
    const weekData = [2, 3, 4, 3, 5, 4, 6];
    const maxVal = Math.max(...weekData, 6);
    weekData.forEach((val, i) => {
        ctx.fillStyle = '#7fb069';
        ctx.fillRect(30 + i*40, 100 - (val/maxVal)*80, 28, (val/maxVal)*80);
        ctx.fillStyle = '#333';
        ctx.font = '12px Poppins';
        ctx.fillText(['Mon','Tue','Wed','Thu','Fri','Sat','Sun'][i], 30 + i*40, 115);
    });
    ctx.font = 'bold 14px Poppins';
    ctx.fillStyle = '#2d5016';
    ctx.fillText('Habits Completed', 100, 20);
    // Environmental impact summary
    const impactDiv = document.createElement('div');
    impactDiv.className = 'progress-impact-summary';
    impactDiv.innerHTML = `<p>🌊 You have saved <b>10%</b> more water this week!</p><p>🌱 Your actions reduced CO₂ by <b>8%</b> compared to last week!</p>`;
    container.appendChild(impactDiv);
    // Motivational quote
    const quoteDiv = document.createElement('div');
    quoteDiv.className = 'eco-score-quote';
    quoteDiv.textContent = getRandomQuote();
    container.appendChild(quoteDiv);
}
// --- Patch: Render progress page on navigation ---
function showPage(pageId) {
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active');
    });
    document.getElementById(pageId).classList.add('active');
    if (pageId === 'progressPage') renderProgressPage();
}

// --- Team Challenges Page Logic (Full Flow) ---
function renderChallengesPage() {
    const container = document.getElementById('challengesList');
    if (!container) return;
    container.innerHTML = '';
    
    // Available challenges list
    const availableChallenges = [
        {
            icon: 'fa-recycle',
            title: '7-Day No-Plastic Challenge',
            objective: 'Complete 5 eco tasks in 7 days',
            duration: '7 days'
        },
        {
            icon: 'fa-bicycle',
            title: 'Green Miles Challenge',
            objective: 'Track eco-friendly travel for 2 weeks',
            duration: '14 days'
        },
        {
            icon: 'fa-leaf',
            title: 'Zero Waste Week',
            objective: 'Generate less than 100g waste per day',
            duration: '7 days'
        },
        {
            icon: 'fa-tree',
            title: 'Tree Planting Team Goal',
            objective: 'Plant 10 trees or donate for reforestation',
            duration: '30 days'
        },
        {
            icon: 'fa-question-circle',
            title: 'EcoQuiz Battles',
            objective: 'Compete in weekly eco-awareness quizzes',
            duration: 'Ongoing'
        },
        {
            icon: 'fa-utensils',
            title: 'Green Cooking Team-Off',
            objective: 'Cook 5 eco-friendly, plant-based meals',
            duration: '10 days'
        },
        {
            icon: 'fa-medal',
            title: 'Green Hero of the Week',
            objective: 'Nominate team members for weekly recognition',
            duration: '7 days'
        }
    ];
    
    // Show available challenges
    const challengesHeader = document.createElement('div');
    challengesHeader.className = 'challenge-phase-card';
    challengesHeader.innerHTML = `
        <div class='challenge-title'>Available Team Challenges</div>
        <div class='challenge-features'>Select a challenge to get started:</div>
    `;
    container.appendChild(challengesHeader);
    
    availableChallenges.forEach((challenge, index) => {
        const challengeCard = document.createElement('div');
        challengeCard.className = 'challenge-card';
        challengeCard.innerHTML = `
            <div class='challenge-icon'><i class='fas ${challenge.icon}'></i></div>
            <div class='challenge-title'>${challenge.title}</div>
            <div class='challenge-goal'><b>Objective:</b> ${challenge.objective}</div>
            <div class='challenge-features'><b>Duration:</b> ${challenge.duration}</div>
            <button class='challenge-btn' onclick='startChallenge(${index})'>Start Challenge</button>
        `;
        container.appendChild(challengeCard);
    });
}

// Function to start a specific challenge
// --- Challenge Team Name/People Prompt ---
let currentTeamName = 'EcoNinjas';
let currentTeamSize = 4;
function startChallenge(challengeIndex) {
    // Prompt for team name and size first
    const container = document.getElementById('challengesList');
    container.innerHTML = '';
    const teamPrompt = document.createElement('div');
    teamPrompt.className = 'challenge-phase-card';
    teamPrompt.innerHTML = `
        <div class='challenge-title'>Enter Team Details</div>
        <form id='teamDetailsForm'>
            <label>Team Name:<br><input type='text' name='teamName' value='EcoNinjas' required></label><br>
            <label>Number of People:<br><input type='number' name='teamSize' value='4' min='1' max='20' required></label><br>
            <button type='submit' class='challenge-btn'>Continue</button>
        </form>
    `;
    container.appendChild(teamPrompt);
    document.getElementById('teamDetailsForm').onsubmit = function(e) {
        e.preventDefault();
        currentTeamName = this.teamName.value;
        currentTeamSize = this.teamSize.value;
        teamPrompt.style.display = 'none';
        showChallengeOnboarding(challengeIndex);
    };
}
function showChallengeOnboarding(challengeIndex) {
    const container = document.getElementById('challengesList');
    container.innerHTML = '';
    
    const challenges = [
        {
            icon: 'fa-recycle',
            title: '7-Day No-Plastic Challenge',
            objective: 'Complete 5 eco tasks in 7 days',
            duration: '7 days',
            rules: [
                'Avoid single-use plastics (bags, bottles, straws, etc.)',
                'Log your actions daily (photo or checkbox)',
                'Each member must confirm participation',
                'Team must complete at least 5 eco tasks in 7 days'
            ],
            points: 'Each task = 10 points. Complete all for a team badge.'
        },
        {
            icon: 'fa-bicycle',
            title: 'Green Miles Challenge',
            objective: 'Track eco-friendly travel for 2 weeks',
            duration: '14 days',
            rules: [
                'Use walking, biking, or public transport',
                'Log your daily travel distance',
                'Track CO2 saved compared to driving',
                'Team with most green kilometers wins'
            ],
            points: 'Each km = 5 points. Team with highest total wins.'
        },
        {
            icon: 'fa-leaf',
            title: 'Zero Waste Week',
            objective: 'Generate less than 100g waste per day',
            duration: '7 days',
            rules: [
                'Weigh your daily waste output',
                'Use reusable containers and bags',
                'Compost organic waste',
                'Avoid packaged foods'
            ],
            points: 'Each day under 100g = 15 points.'
        },
        {
            icon: 'fa-tree',
            title: 'Tree Planting Team Goal',
            objective: 'Plant 10 trees or donate for reforestation',
            duration: '30 days',
            rules: [
                'Plant trees locally or donate to reforestation',
                'Upload photos of planting activities',
                'Track virtual forest growth',
                'Share progress on social media'
            ],
            points: 'Each tree = 20 points. Complete goal for special badge.'
        },
        {
            icon: 'fa-question-circle',
            title: 'EcoQuiz Battles',
            objective: 'Compete in weekly eco-awareness quizzes',
            duration: 'Ongoing',
            rules: [
                'Take weekly eco quizzes',
                'Answer questions about sustainability',
                'Compete with other teams',
                'Unlock new challenge categories'
            ],
            points: 'Each correct answer = 5 points. Weekly leaderboard.'
        },
        {
            icon: 'fa-utensils',
            title: 'Green Cooking Team-Off',
            objective: 'Cook 5 eco-friendly, plant-based meals',
            duration: '10 days',
            rules: [
                'Cook plant-based meals',
                'Use local, seasonal ingredients',
                'Minimize food waste',
                'Share recipes and photos'
            ],
            points: 'Each meal = 25 points. Best recipe gets bonus.'
        },
        {
            icon: 'fa-medal',
            title: 'Green Hero of the Week',
            objective: 'Nominate team members for weekly recognition',
            duration: '7 days',
            rules: [
                'Nominate team members for eco efforts',
                'Share stories of environmental impact',
                'Vote for weekly winners',
                'Feature winners in app'
            ],
            points: 'Each nomination = 10 points. Winner gets 50 bonus points.'
        }
    ];
    
    const challenge = challenges[challengeIndex];
    
    // 1. Challenge Onboarding
    const onboarding = document.createElement('div');
    onboarding.className = 'challenge-phase-card';
    onboarding.innerHTML = `
        <div class='challenge-icon'><i class='fas ${challenge.icon}'></i></div>
        <div class='challenge-title'>${challenge.title}</div>
        <div class='challenge-goal'><b>Objective:</b> ${challenge.objective}</div>
        <div class='challenge-features'><b>Duration:</b> ${challenge.duration}</div>
        <div class='challenge-features'><b>Rules:</b><ul>${challenge.rules.map(r=>`<li>${r}</li>`).join('')}</ul></div>
        <div class='challenge-features'><b>Points:</b> ${challenge.points}</div>
        <button class='challenge-btn' id='confirmParticipationBtn'>I'm in!</button>
    `;
    container.appendChild(onboarding);
    document.getElementById('confirmParticipationBtn').onclick = () => {
        onboarding.style.display = 'none';
        showTeamCoordination();
    };
    
    // Continue with the rest of the challenge flow...
    function showTeamCoordination() {
        const teamCoord = document.createElement('div');
        teamCoord.className = 'challenge-phase-card';
        teamCoord.innerHTML = `
            <div class='challenge-title'>Team Coordination</div>
            <div class='challenge-features'>Discuss strategies, assign sub-tasks, and chat below:</div>
            <div class='team-chat-box' id='teamChatBox'></div>
            <input id='teamChatInput' class='team-chat-input' placeholder='Type a message...'>
            <button class='challenge-btn' id='sendChatBtn'>Send</button>
            <div class='challenge-features'>Assignments:<ul><li>Ryan: Avoid plastic bags</li><li>Alex: No packaged drinks</li></ul></div>
            <button class='challenge-btn' id='startLoggingBtn'>Start Daily Logging</button>
        `;
        container.appendChild(teamCoord);
        let chatBox = teamCoord.querySelector('#teamChatBox');
        let chatInput = teamCoord.querySelector('#teamChatInput');
        teamCoord.querySelector('#sendChatBtn').onclick = () => {
            if (chatInput.value.trim()) {
                chatBox.innerHTML += `<div class='chat-msg'><b>You:</b> ${chatInput.value}</div>`;
                chatInput.value = '';
            }
        };
        teamCoord.querySelector('#startLoggingBtn').onclick = () => {
            teamCoord.style.display = 'none';
            showDailyTaskLogging();
        };
    }
    
    function showDailyTaskLogging() {
        const dailyLog = document.createElement('div');
        dailyLog.className = 'challenge-phase-card';
        dailyLog.innerHTML = `
            <div class='challenge-title'>Daily Task Logging</div>
            <div class='challenge-features'>Log your eco-friendly actions for today:</div>
            <div class='daily-tasks-list'>
                <label><input type='checkbox'> Avoided plastic bag</label><br>
                <label><input type='checkbox'> No packaged drink</label><br>
                <label><input type='checkbox'> Used reusable bottle</label><br>
                <label><input type='checkbox'> Visited farmer's market</label><br>
            </div>
            <div class='challenge-features'>Upload a photo: <input type='file' accept='image/*'></div>
            <button class='challenge-btn' id='logDayBtn'>Log Today's Actions</button>
        `;
        container.appendChild(dailyLog);
        dailyLog.querySelector('#logDayBtn').onclick = () => {
            dailyLog.style.display = 'none';
            showTeamProgress();
        };
    }
    
    function showTeamProgress() {
        const progress = document.createElement('div');
        progress.className = 'challenge-phase-card';
        progress.innerHTML = `
            <div class='challenge-title'>Team Progress</div>
            <div class='challenge-features'>
                <div class='progress-bar-outer'><div class='progress-bar-inner' style='width:80%'></div></div>
                <div>Team Streak: <b>6 days</b></div>
                <div>Total Points: <b>240</b></div>
                <div>Leaderboard: <b>2nd place</b></div>
            </div>
            <div class='challenge-features team-motivation'>"Team EcoNinjas is 80% done – let's go!"</div>
            <button class='challenge-btn' id='completeChallengeBtn'>Complete Challenge</button>
        `;
        container.appendChild(progress);
        progress.querySelector('#completeChallengeBtn').onclick = () => {
            progress.style.display = 'none';
            showCompletionSummary(challenge);
        };
    }
    
    function showCompletionSummary(challenge) {
        const summary = document.createElement('div');
        summary.className = 'challenge-phase-card';
        summary.innerHTML = `
            <div class='challenge-title'>Challenge Completed!</div>
            <div class='challenge-features'>
                <b>Team:</b> ${currentTeamName}<br>
                <b>CO₂ Saved:</b> 2.5kg<br>
                <b>Tasks Completed:</b> 7/7<br>
            </div>
            <div class='challenge-features'>
                <b>Badge:</b> <span class='challenge-badge'>🏅 Green Champions – ${challenge.title} Completed!</span>
            </div>
            <button class='challenge-btn' id='downloadCertBtn'>Download Certificate</button>
            <button class='challenge-btn' id='reflectBtn'>Reflect & Share</button>
        `;
        container.appendChild(summary);
        summary.querySelector('#downloadCertBtn').onclick = () => {
            downloadTeamCertificate(currentTeamName, challenge.title);
        };
        summary.querySelector('#reflectBtn').onclick = () => {
            summary.style.display = 'none';
            showReflectionSharing();
        };
    }
    
    function showReflectionSharing() {
        const reflect = document.createElement('div');
        reflect.className = 'challenge-phase-card';
        reflect.innerHTML = `
            <div class='challenge-title'>Reflection & Sharing</div>
            <div class='challenge-features'>Upload a photo or write your eco-story:</div>
            <textarea class='eco-story-input' placeholder='How we completed this challenge as a team...'></textarea>
            <input type='file' accept='image/*'><br>
            <button class='challenge-btn' id='shareStoryBtn'>Share on Eco Wall of Fame</button>
        `;
        container.appendChild(reflect);
        reflect.querySelector('#shareStoryBtn').onclick = () => {
            reflect.style.display = 'none';
            showNextChallengePrompt();
        };
    }
    
    function showNextChallengePrompt() {
        const next = document.createElement('div');
        next.className = 'challenge-phase-card';
        next.innerHTML = `
            <div class='challenge-title'>You crushed this! Try this next one?</div>
            <div class='challenge-features'>
                <button class='challenge-btn' onclick='renderChallengesPage()'>Back to Challenges</button>
            </div>
        `;
        container.appendChild(next);
    }
}
// --- Patch: Render challenges page on navigation ---
const origShowPage = showPage;
showPage = function(pageId) {
    origShowPage(pageId);
    if (pageId === 'challengesPage') renderChallengesPage();
};

// --- Leaderboard Page Logic ---
function renderLeaderboardPage() {
    const container = document.getElementById('leaderboardList');
    if (!container) return;
    container.innerHTML = '';
    // Demo data: teams/users and their weekly progress
    const teams = [
        { name: 'EcoNinjas', color: '#ff6b35', progress: [200, 320, 320, 400, 360, 440, 620, 770, 500, 540, 340] },
        { name: 'GreenWarriors', color: '#4a7c59', progress: [150, 280, 300, 350, 320, 380, 520, 650, 420, 480, 300] },
        { name: 'PlanetSavers', color: '#a7c957', progress: [100, 220, 240, 280, 260, 320, 450, 580, 380, 420, 280] }
    ];
    // Find leader
    const leader = teams.reduce((a, b) => b.progress[10] > a.progress[10] ? b : a, teams[0]);
    // Leaderboard header
    const header = document.createElement('div');
    header.className = 'leaderboard-header';
    header.innerHTML = `<b>🏆 Leading Team: <span style='color:${leader.color}'>${leader.name}</span> (${leader.progress[10]} points this week)</b>`;
    container.appendChild(header);
    // Line graph
    const graph = document.createElement('canvas');
    graph.width = 600;
    graph.height = 300;
    graph.className = 'leaderboard-graph';
    container.appendChild(graph);
    const ctx = graph.getContext('2d');
    // Draw axes
    ctx.strokeStyle = '#ff6b35';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(60, 40); ctx.lineTo(60, 260); ctx.lineTo(560, 260);
    ctx.stroke();
    // Draw Y-axis labels
    ctx.fillStyle = '#333';
    ctx.font = '12px Poppins';
    for (let i = 0; i <= 5; i++) {
        const y = 260 - (i * 44);
        ctx.fillText(i * 200, 30, y + 4);
    }
    // Draw X-axis labels
    for (let i = 0; i <= 10; i += 2) {
        const x = 60 + (i * 50);
        ctx.fillText(i, x - 4, 280);
    }
    // Draw lines for each team
    teams.forEach(team => {
        ctx.strokeStyle = team.color;
        ctx.lineWidth = 3;
        ctx.setLineDash([8, 4]);
        ctx.beginPath();
        team.progress.forEach((val, i) => {
            const x = 60 + i * 50;
            const y = 260 - (val / 1000) * 220;
            if (i === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
        });
        ctx.stroke();
        ctx.setLineDash([]);
        // Draw circular markers
        team.progress.forEach((val, i) => {
            const x = 60 + i * 50;
            const y = 260 - (val / 1000) * 220;
            ctx.fillStyle = team.color;
            ctx.beginPath();
            ctx.arc(x, y, 4, 0, 2 * Math.PI);
            ctx.fill();
        });
        // Draw team name at end
        ctx.fillStyle = team.color;
        ctx.font = 'bold 14px Poppins';
        ctx.fillText(team.name, 60 + 10 * 50 + 10, 260 - (team.progress[10] / 1000) * 220);
    });
    // List teams and points
    const list = document.createElement('div');
    list.className = 'leaderboard-list';
    list.innerHTML = teams.map((t, idx) => `<div class='leaderboard-row' style='color:${t.color}'><b>${idx+1}. ${t.name}</b> – ${t.progress[10]} points</div>`).join('');
    container.appendChild(list);
}
// --- Patch: Render leaderboard page on navigation ---
const origShowPageLB = showPage;
showPage = function(pageId) {
    origShowPageLB(pageId);
    if (pageId === 'leaderboardPage') renderLeaderboardPage();
    if (pageId === 'challengesPage') renderChallengesPage();
    if (pageId === 'progressPage') renderProgressPage();
};
