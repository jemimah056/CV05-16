const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs').promises;

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('.'));

// Data storage (in production, use a proper database)
let userData = {};
let activitiesData = {};

// Routes
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// User data endpoints
app.post('/api/user/save', (req, res) => {
    const { userId, data } = req.body;
    userData[userId] = {
        ...data,
        lastUpdated: new Date().toISOString()
    };
    res.json({ success: true, message: 'User data saved successfully' });
});

app.get('/api/user/:userId', (req, res) => {
    const { userId } = req.params;
    const user = userData[userId];
    
    if (user) {
        res.json({ success: true, data: user });
    } else {
        res.status(404).json({ success: false, message: 'User not found' });
    }
});

// Activities endpoints
app.post('/api/activities/complete', (req, res) => {
    const { userId, activityId, completed } = req.body;
    
    if (!activitiesData[userId]) {
        activitiesData[userId] = {};
    }
    
    const today = new Date().toDateString();
    if (!activitiesData[userId][today]) {
        activitiesData[userId][today] = [];
    }
    
    if (completed) {
        if (!activitiesData[userId][today].includes(activityId)) {
            activitiesData[userId][today].push(activityId);
        }
    } else {
        activitiesData[userId][today] = activitiesData[userId][today].filter(id => id !== activityId);
    }
    
    res.json({ success: true, message: 'Activity status updated' });
});

app.get('/api/activities/:userId', (req, res) => {
    const { userId } = req.params;
    const userActivities = activitiesData[userId] || {};
    res.json({ success: true, data: userActivities });
});

// Leaderboard endpoint
app.get('/api/leaderboard', (req, res) => {
    const leaderboard = Object.keys(userData).map(userId => {
        const user = userData[userId];
        const userActivitiesData = activitiesData[userId] || {};
        
        let totalPoints = 0;
        Object.values(userActivitiesData).forEach(dayActivities => {
            totalPoints += dayActivities.length * 10; // Simple point calculation
        });
        
        return {
            userId,
            name: user.name || 'Anonymous',
            points: totalPoints,
            streak: user.streak || 0
        };
    }).sort((a, b) => b.points - a.points);
    
    res.json({ success: true, data: leaderboard });
});

// Weekly progress endpoint
app.get('/api/progress/:userId', (req, res) => {
    const { userId } = req.params;
    const userActivitiesData = activitiesData[userId] || {};
    
    const weeklyProgress = [];
    const today = new Date();
    
    for (let i = 6; i >= 0; i--) {
        const date = new Date(today);
        date.setDate(date.getDate() - i);
        const dateString = date.toDateString();
        
        const dayActivities = userActivitiesData[dateString] || [];
        weeklyProgress.push({
            date: dateString,
            activitiesCompleted: dayActivities.length,
            points: dayActivities.length * 10
        });
    }
    
    res.json({ success: true, data: weeklyProgress });
});

// Start server
app.listen(PORT, () => {
    console.log(`EcoFy server running on http://localhost:${PORT}`);
    console.log('🌱 Welcome to EcoFy - Your Eco-friendly Habit Tracker!');
});

module.exports = app;
